<?php $__env->startSection('styles'); ?>
 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <table id="recordsTable" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Task Name</th>
                <th>Description</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>
<script>
let token = '<?php echo e(csrf_token()); ?>';
</script>
<script src="<?php echo e(asset('js/allRecords.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects-web\timezone-awareapp\timezone_awareapp\resources\views/allRecords.blade.php ENDPATH**/ ?>